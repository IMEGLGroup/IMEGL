//
//  ViewController.swift
//  addEventInCalendar
//
//  Created by Ranauro Lorena on 14/02/18.
//  Copyright © 2018 Ranauro Lorena. All rights reserved.
//

// https://www.youtube.com/watch?v=sSFzcvvs4Oc

import UIKit
import EventKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view, typically from a nib.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }

    @IBAction func btnAddEventTapped(_ sender: Any) {
        let eventStore : EKEventStore = EKEventStore()
        
        eventStore.requestAccess(to: .event) { (granted, error) in
            
            if (granted) &&  (error  == nil)
            {
                print("granted \(granted)")
                print("error \(error)")
                
                let event: EKEvent = EKEvent(eventStore: eventStore)
                event.title = "Add event testing Title"
                event.startDate = Date()
                event.endDate = Date()
                event.notes = "This is note"
                event.calendar = eventStore.defaultCalendarForNewEvents
                do {
                    try eventStore.save(event, span: .thisEvent)
                } catch let error as NSError {
                    print("error: \(error)")
                }
                print("Save Event")
            }
            else {
                print("error : \(error)")
            }
            
            
        }
    }
    
}

