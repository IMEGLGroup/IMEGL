//
//  GestoreDati.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 13/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import Foundation

class GestoreDati: NSObject {
    
    
    override init() {}
    
    func writeToDocumentsFile(fileName:String,value:String) {
        let dir = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first
        let path = dir?.appendingPathComponent(fileName)
        
        let file: FileHandle? = try! FileHandle.init(forWritingTo: path!)
        
        print(file)
        if file != nil {
            // Set the data we want to write
            let data = value.data(using: .utf8)
            print(data)
            // Write it to the file
            file?.seekToEndOfFile()
            file?.write(data!)
            
            // Close the file
            file?.closeFile()
        }
        else {
            print("Ooops! Something went wrong!")
        }
    }
    func readFromDocumentsFile(fileName:String) -> String {
        
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        let path = documentsPath.appendingPathComponent(fileName)
        
        var readText : String = ""
        
        do {
            try readText = NSString(contentsOfFile: path, encoding: String.Encoding.utf8.rawValue) as String
        }
        catch let error as NSError {
            print("ERROR : reading from file \(fileName) : \(error.localizedDescription)")
        }
        return readText
    }
    
    
}
