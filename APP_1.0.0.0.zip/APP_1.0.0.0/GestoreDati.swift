//
//  GestoreDati.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 13/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import Foundation

class GestoreDati: NSObject {
    
    
    override init() {}
    
    func writeToDocumentsFile(fileName:String,value:String) {
        
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true).last as NSString!
        let path = documentsPath?.appendingPathComponent(fileName)
        
        do {
            try value.write(toFile: path!, atomically: true, encoding: String.Encoding.utf8)
        } catch let error as NSError {
            print("ERROR : writing to file \(String(describing: path)) : \(error.localizedDescription)")
        }
        
    }
    
    func readFromDocumentsFile(fileName:String) -> String {
        
        let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
        let path = documentsPath.appendingPathComponent(fileName)
        
        var readText : String = ""
        
        do {
            try readText = NSString(contentsOfFile: path, encoding: String.Encoding.utf8.rawValue) as String
        }
        catch let error as NSError {
            print("ERROR : reading from file \(fileName) : \(error.localizedDescription)")
        }
        return readText
    }
    
    
}
