//
//  RegistrationViewController.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 13/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class Registration: UIViewController {
    
    
    @IBOutlet var name: UITextField!
    @IBOutlet var surname: UITextField!
    @IBOutlet var address: UITextField!
    @IBOutlet var matricola: UITextField!
    @IBOutlet var mail: UITextField!
    @IBOutlet var password: UITextField!
    
    @IBOutlet var prova: UISwitch!
    
    
    
    
    
    @IBAction func Registrati(_ sender: Any) {
        
        
        if prova.isOn {
            
            //qui creo un nuovo professore
            //bisogna aggiungere i controlli e verificare che siano tutte le text piene
            let doc : Teacher = Teacher(name: name.text!, cognome: surname.text!, mail: mail.text!, matricola: matricola.text!, indirizzo: address.text!, password: password.text!)
            
            //creo il path che andra nel file
            let docInfo = (doc.mail+" "+doc.password+" "+doc.name+" "+doc.cognome+" "+doc.matricola+" "+doc.indirizzo+"\n")
            
            //converto in data
            let data = docInfo.data(using: .utf8)
           
            
            let dir = FileManager.default.urls(for: .developerDirectory, in: .userDomainMask).first
            
            print(dir)
            let path = dir?.appendingPathComponent("docenti.txt")
            print(path)
            
            // se esiste bene se no lo creo
            if !(FileManager.default.fileExists(atPath: (path!.path))){
                FileManager.default.createFile(atPath: (path?.path)!, contents: nil, attributes: nil)
            }
            else{
                //CREO L'HANDLE
                print("sto qua")
                let file: FileHandle? = try!FileHandle.init(forWritingTo: path!)
                //prendo la fine del file
                file?.seekToEndOfFile()
                //scrivo il dato
                file?.write(data!)
                //chiudo il file
                file?.closeFile()
                //bisogna mettere sta roba in una funzione
            }
         
        }
        
        
    }

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
