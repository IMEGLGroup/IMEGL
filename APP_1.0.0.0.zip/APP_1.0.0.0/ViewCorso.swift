//
//  ViewCorso.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class ViewCorso: UIViewController {

    var teacher : Teacher? = nil
    var studente : Student? = nil
    var isDocent = true
    var c : String = " "
    @IBOutlet var nomeCorso: UINavigationBar!
    @IBOutlet var nomeTeac: UITextView!
    @IBOutlet var location: UITextView!
    @IBOutlet var program: UITextView!
    @IBOutlet var data: UITextView!
    @IBOutlet var book: UITextView!
    @IBOutlet var contacts: UITextView!

    
    @IBAction func main(_ sender: Any) {
    }
    override func viewDidLoad() {
        if isDocent{
            let s = filtraTraiCorsi(s: c)
            
            nomeTeac.text = s.nomeTeacher
            location.text = s.location
            program.text = s.programmaCorso
            data.text = s.orario
            book.text = s.libri
            contacts.text = teacher?.mail
        }else{
        }
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func filtraTraiCorsi(s : String)-> Course{
        let corso : Course! = nil
        
                if isDocent{
                    for i in 0 ..< teacher!.corsi.count {
                            if teacher!.corsi[i].nomeCorso == s {
                               return  teacher!.corsi[i]
                            }
                    }
                }else {
                    for i in 0 ..< studente!.corsiSeguiti.count {
                        if studente!.corsiSeguiti[i].nomeCorso == s {
                            return studente!.corsiSeguiti[i]
                            }
                    }
                    
        }
        return corso!
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
