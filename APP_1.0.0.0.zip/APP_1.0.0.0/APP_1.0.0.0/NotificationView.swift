//
//  NotificationView.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class NotificationView: UIViewController {
    var alert: UIAlertController!

    var isDocent : Bool = true
    var teacher : Teacher? = nil
    var studente : Student? = nil
    
    
    @IBAction func notDisurb(_ sender: Any) {
         allarme("Action","Not disturbed push")
    }
    
    @IBAction func changeCourse(_ sender: Any) {
        allarme("Action","change course push")
    }
    
    @IBAction func advice(_ sender: Any) {
        allarme("Action","Advise push")
    }
 
    @IBOutlet var delay: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func allarme(_ title:String, _ message:String){
        alert = UIAlertController(title: "Change Allarm", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let actionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default)
        alert.addAction(actionOk)
        self.present(self.alert, animated: true, completion: nil)
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let desinationT = segue.destination as! TabController
        let destination0 = desinationT.viewControllers![0] as! MainCourse
        let destination1 = desinationT.viewControllers![1] as! AdviseView
        let destination2 = desinationT.viewControllers![3] as! Setting
        
        if isDocent{
            destination0.docente = teacher
            destination0.isdocent = true
            destination1.docent = teacher
            destination1.isDocent = true
            destination2.docente = self.teacher
            destination2.isDocent = true
        } else{
            destination0.studente = studente
            destination0.isdocent = false
            destination1.isDocent = false
            destination2.studente = self.studente
            destination2.isDocent = false
        }
        
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
