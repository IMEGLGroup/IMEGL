//
//  NotificationView.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class NotificationView: UIViewController {
    var alert: UIAlertController!

   
    @IBAction func notDisurb(_ sender: Any) {
         allarme("Action","Not disturbed push")
    }
    
    @IBAction func changeCourse(_ sender: Any) {
        allarme("Action","change course push")
    }
    
    @IBAction func advice(_ sender: Any) {
        allarme("Action","Advise push")
    }
 
    @IBOutlet var delay: UISwitch!
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func allarme(_ title:String, _ message:String){
        alert = UIAlertController(title: "Change Allarm", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let actionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default)
        alert.addAction(actionOk)
        self.present(self.alert, animated: true, completion: nil)
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
