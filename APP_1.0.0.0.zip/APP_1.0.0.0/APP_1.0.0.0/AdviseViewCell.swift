//
//  AdviseViewCell.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 17/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class AdviseViewCell: UITableViewCell {

    @IBOutlet var labelTeaName: UILabel!
    @IBOutlet var labelTitolo: UILabel!
    
    
    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(_ selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
