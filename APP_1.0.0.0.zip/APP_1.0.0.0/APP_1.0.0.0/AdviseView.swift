//
//  AdviseView.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class AdviseView: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    @IBOutlet var add: UIBarButtonItem!
    var docent : Teacher? = nil
    var student : Student? = nil
    var isDocent : Bool = true
    var avviso : Advise? = nil
    
    var avvisi : [Advise] = [Advise(titolo: "Spostamento esame Sistemi dinamici", corpo: "Si avvisano gli studenti che l'esame sarà spostato alle ore 3 in aula b3", ora: "13,00", nomeTeacher: "Ester Zeoli"),Advise(titolo: "Nuovo corso di Java", corpo: "Si avvisano gli studenti che sara a breve accedere a un nuovo corso di formazione per Java", ora: "17,00", nomeTeacher: "Giuseppe Del Monaco")]
   

    override func viewDidLoad() {
        if avviso != nil {
                    avvisi.append(avviso!)
                }
        if isDocent == false{
                    add.isEnabled = false
                    add.title = " "
                    }
            super.viewDidLoad()
        }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
            return avvisi.count
        }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cellidentifier = "celleAvvisi"
        let cella = tableView.dequeueReusableCell(withIdentifier: cellidentifier , for: indexPath ) as! AdviseViewCell

           cella.labelTeaName.text = avvisi[indexPath.row].nomeTeacher
           cella.labelTitolo.text = avvisi[indexPath.row].titolo

        return cella
    }

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "createSegue"{
            let destination = segue.destination as! CreateAdvise
            destination.docent = self.docent
        }else if segue.identifier == "viewAdviseSegue"{
            let destination = segue.destination as! AdviseDetail
            if isDocent{
                let selectedCell = sender as? AdviseViewCell
                destination.teacher = docent
                destination.isDocent = true
                let avviso =  filtroAdvise(nomeC: (selectedCell?.labelTitolo.text)!, nomeD: (selectedCell?.labelTeaName.text)!)
                destination.avviso = avviso
              
            }else {
                let selectedCell = sender as? AdviseViewCell
                destination.studente = student
                destination.isDocent = false
                             let avviso =  filtroAdvise(nomeC: (selectedCell?.labelTitolo.text)!, nomeD: (selectedCell?.labelTeaName.text)!)
                destination.avviso = avviso
            }
        }
    }
    func filtroAdvise(nomeC : String, nomeD : String)-> Advise{
       
        for i in 0 ..< avvisi.count {
            if avvisi[i].nomeTeacher == nomeD && avvisi[i].titolo == nomeC {
                return avvisi[i]
            }
        }
        return avvisi[0]
    }

}
