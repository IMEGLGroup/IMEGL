//
//  AdviseView.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class AdviseView: UIViewController,UITableViewDelegate, UITableViewDataSource {
    
    var docent : Teacher? = nil
    var isDocent : Bool = true
    var avviso : Advise? = nil
    
    var avvisi : [Advise] = [Advise(titolo: "Spostamento esame Sistemi dinamici", corpo: "Si avvisano gli studenti che l'esame sarà spostato alle ore 3 in aula b3", ora: "13,00", nomeTeacher: "Ester Zeoli"),Advise(titolo: "Nuovo corso di Java", corpo: "Si avvisano gli studenti che sara a breve accedere a un nuovo corso di formazione per Java", ora: "17,00", nomeTeacher: "Giuseppe Del Monaco")]
   

    override func viewDidLoad() {
        print(isDocent)
        print(docent?.name)
        print(docent?.corsi.count)
        if avviso != nil {
            avvisi.append(avviso!)
        }
        super.viewDidLoad()
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
   
        func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    
            return avvisi.count
        }
    

    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {

        let cellidentifier = "celleAvvisi"
        let cella = tableView.dequeueReusableCell(withIdentifier: cellidentifier , for: indexPath ) as! AdviseViewCell

           cella.labelTeaName.text = avvisi[indexPath.row].nomeTeacher
           cella.labelTitolo.text = avvisi[indexPath.row].titolo

        return cella
    }

    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        if segue.identifier == "createSegue"{
            let destination = segue.destination as! CreateAdvise
            destination.docent = self.docent
        }
    }
////    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
//        super .prepare(for: segue, sender: sender)
//        if segue.identifier == "createSegue"{
//            let destination = segue.destination as! CreateCourseViewController
//            destination.teacher = docente
//        } else if segue.identifier == "viewSegue"{
//            let destination = segue.destination as! ViewCorso
//            let selectedCell = sender as? Celle
//            destination.teacher = docente
//            destination.isDocent = true
//            print(selectedCell!.labelCorso.text)
//            var c = selectedCell?.labelCorso.text
//            print(c)
//            destination.c = c!
//        }
//    }
//

}
