//
//  Student.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 12/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import Foundation

class Student: NSObject {
    
    var name : String
    var cognome : String
    var mail : String
    var password : String
    var matricola : String
    var corsiSeguiti : [Course] = []
  
    init(nome : String, cognome: String,mail: String, matricola : String, password: String, corsiSeguiti : [Course]) {
        self.name = nome
        self.cognome = cognome
        self.mail = mail //key
        self.matricola = matricola //key
        self.password = password //private
        //qua metto un array statico in realta ci va un array dinamico 
        self.corsiSeguiti = corsiSeguiti
        
    }

}
