//
//  CreateCourseViewController.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class CreateCourseViewController: UIViewController {

    var teacher : Teacher! = nil
    var alert: UIAlertController!
    
    @IBOutlet var nomeCorso: UITextField!
    @IBOutlet var location: UITextField!
    @IBOutlet var program: UITextField!
    @IBOutlet var book: UITextField!
    @IBOutlet var contacts: UITextField!
    @IBOutlet var dataStart: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func done(_ sender: Any) {
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        
        if self.nomeCorso.text == "" {
            self.nomeCorso.placeholder = "Insert name course"
            allarme("Error","Insert a name of course")
        }else if self.location.text == ""{
            //qua si dovrebbe controllare se è giusta
            self.location.placeholder = "Insert a location"
            allarme("Error","Insert your surname")
        }else if self.program.text == ""{
            self.program.placeholder = "Insert a little program or links"
            allarme("Error","Insert a program")
        }else if self.dataStart.text == ""{
            //qui andrebbe fatto meglio ma il tempo è poco
            self.dataStart.placeholder = "Insert a a date"
            allarme("Error","Insert a date/hour")}else {
            
            
            var c = Course.init(nomeCorso: nomeCorso.text!, nomeTeacher: (teacher.name), orario: dataStart.text!, location: location.text!, programmaCorso: program.text!, libri: book.text!)
           
        
            // ritorno al main
            let destination = segue.destination as! MainCourse
            
                destination.docente = teacher
            
                destination.corso.append(c)
            
                destination.isdocent = true
        }
    }
    
    func allarme(_ title:String, _ message:String){
        alert = UIAlertController(title: "Creation Error", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let actionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default)
        alert.addAction(actionOk)
        self.present(self.alert, animated: true, completion: nil)
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
