//
//  CreateCourseViewController.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import Foundation

class CreateCourseViewController: UIViewController {

    var teacher : Teacher? = nil
    var alert: UIAlertController!
    
    @IBOutlet var nomeCorso: UITextField!
    @IBOutlet var location: UITextField!
    @IBOutlet var program: UITextField!
    @IBOutlet var book: UITextField!
    @IBOutlet var contacts: UITextField!
    @IBOutlet var dataStart: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        print(teacher?.corsi.count)
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func done(_ sender: Any) {
        
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        if segue.identifier == "doneSegue"{
            
            if self.nomeCorso.text == "" {
                self.nomeCorso.placeholder = "Insert name course"
                allarme("Error","Insert a name of course")
            }else if self.location.text == ""{
                //qua si dovrebbe controllare se è giusta
                self.location.placeholder = "Insert a location"
                allarme("Error","Insert your surname")
            }else if self.program.text == ""{
                self.program.placeholder = "Insert a little program or links"
                allarme("Error","Insert a program")
            }else if self.dataStart.text == ""{
                //qui andrebbe fatto meglio ma il tempo è poco
                self.dataStart.placeholder = "Insert a a date"
                allarme("Error","Insert a date/hour")
                
            }else {
                
                let c = Course(nomeCorso: nomeCorso.text!, nomeTeacher: (teacher?.name)!, orario: dataStart.text!, location: location.text!, programmaCorso: program.text!, libri: book.text!)
                
                // ritorno al main
                let destinationTab = segue.destination as! TabController
               
                let destination0 = destinationTab.viewControllers![0] as! MainCourse
                
                let destination1 = destinationTab.viewControllers![1] as! AdviseView
                
                let destination2 = destinationTab.viewControllers![3] as! Setting
                teacher?.corsi.append(c)
                destination0.docente = teacher
                destination0.corso.append(c)
                destination0.isdocent = true
               
                destination1.docent = teacher
                destination1.isDocent = true
                
                destination2.isDocent = true
                destination2.docente = teacher
                
                
            }
            
        }else if segue.identifier == "undoCSegue" {
            let destinationTab = segue.destination as! TabController
            
            let destination0 = destinationTab.viewControllers![0] as! MainCourse
            
            let destination1 = destinationTab.viewControllers![1] as! AdviseView
            
            let destination2 = destinationTab.viewControllers![3] as! Setting
            
            destination0.docente = teacher
            destination0.isdocent = true
           
            destination1.docent = teacher
            destination1.isDocent = true
            
            destination2.isDocent = true
            destination2.docente = teacher
            
            
        }
        
     
    }
    
    
    func allarme(_ title:String, _ message:String){
        alert = UIAlertController(title: "Creation Error", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let actionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default)
        alert.addAction(actionOk)
        self.present(self.alert, animated: true, completion: nil)
    }

}
