//
//  Setting.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class Setting: UIViewController {
   
    var isDocent : Bool = true
    var docente : Teacher? = nil
    var studente : Student? = nil
    
    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    @IBAction func profile(_ sender: Any) {
    }
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        print(docente?.corsi.count)
        if segue.identifier == "viewProfileSegue" {
            let destination = segue.destination as! Profile
            if isDocent{
                print(docente?.corsi.count)
                destination.docente = self.docente
                destination.isDocent = true
            }else {
                destination.studente = self.studente
                destination.isDocent = false
            }
        }else if segue.identifier == "notificationSegue"{
            let destination = segue.destination as! NotificationView
            if isDocent{
                print(docente?.corsi.count)
                destination.teacher = self.docente
                destination.isDocent = true
                }else {
                    destination.studente = self.studente
                    destination.isDocent = false
                }
        }else if segue.identifier == "logoutSegue"{
            print("bye bye")
        }
    }


}
