//
//  CreateAdvise.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 18/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import Foundation

class CreateAdvise: UIViewController {

    @IBOutlet var titleAdvise: UITextField!
    @IBOutlet var textAdvise: UITextView!
    
    //valori per il segue
    var docent : Teacher? = nil
    
    @IBOutlet var data: UITextField!
    
    @IBAction func done(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        print(docent?.corsi.count)
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationTab = segue.destination as! TabController
        
        let destination = destinationTab.viewControllers![1] as! AdviseView
        let destination2 = destinationTab.viewControllers![0] as! MainCourse
        // gestione delle test
        if segue.identifier == "undoSegue"{
            destination2.docente = self.docent
            destination.docent = self.docent
            destination2.isdocent = true
            destination.isDocent = true
        }else if segue.identifier == "adviseSegui"{
            print(docent?.corsi.count)
            destination2.docente = self.docent
            destination.isDocent = true
            destination2.isdocent = true
            destination.docent = self.docent

            destination.avviso = Advise(titolo: titleAdvise.text!, corpo: textAdvise.text!, ora: data.text!, nomeTeacher: (docent?.name)!+" "+(docent?.cognome)!)
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
