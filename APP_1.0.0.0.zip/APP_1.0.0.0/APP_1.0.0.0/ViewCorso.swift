//
//  ViewCorso.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class ViewCorso: UIViewController {

    var teacher : Teacher? = nil
    var studente : Student? = nil
    var isDocent = true
    
    var c : String = " "
    @IBOutlet var nomeCorso: UINavigationBar!
    @IBOutlet var nomeTeac: UITextView!
    @IBOutlet var location: UITextView!
    @IBOutlet var program: UITextView!
    @IBOutlet var data: UITextView!
    @IBOutlet var book: UITextView!
    @IBOutlet var contacts: UITextView!

    @IBOutlet var edit: UIBarButtonItem!
    @IBOutlet var done: UIBarButtonItem!
    
    @IBAction func main(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        
            let s = filtraTraiCorsi(s: c)
            nomeTeac.text = s.nomeTeacher
            location.text = s.location
            program.text = s.programmaCorso
            data.text = s.orario
            book.text = s.libri
            contacts.text = teacher?.mail
                if isDocent {
                    edit.isEnabled = true
                    edit.title = "Edit"
                }else {
                    edit.isEnabled = false
                    edit.title = " "
                }
        
    super.viewDidLoad()
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    func filtraTraiCorsi(s : String)-> Course{
        let corso : Course! = nil
        
                if isDocent{
                    for i in 0 ..< teacher!.corsi.count {
                            if teacher!.corsi[i].nomeCorso == s {
                               return  teacher!.corsi[i]
                            }
                    }
                }else {
                    for i in 0 ..< studente!.corsiSeguiti.count {
                        if studente!.corsiSeguiti[i].nomeCorso == s {
                            return studente!.corsiSeguiti[i]
                            }
                    }
                    
        }
        return corso!
    }
    
    @IBAction func edit(_ sender: Any) {
    }
    @IBAction func back(_ sender: Any) {
    }
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let desinationT = segue.destination as! TabController
        let destination0 = desinationT.viewControllers![0] as! MainCourse
        let destination1 = desinationT.viewControllers![1] as! AdviseView
        
        if segue.identifier == "gpsSegue"{
//            per ora non fa nulla
        }else if segue.identifier == "backSegue"{
            if isDocent{
                destination0.docente = teacher
                destination0.isdocent = true
                    destination1.docent = teacher
                    destination1.isDocent = true
            } else{
                destination0.studente = studente
                destination0.isdocent = false
                destination1.isDocent = false
            }
            
        }else if segue.identifier == "editSegue"{
            // qua dovremmo fare i settaggi
            if isDocent{
                destination0.docente = teacher
                destination0.isdocent = true
                destination1.docent = teacher
                destination1.isDocent = true
            } else{
                destination0.studente = studente
                destination0.isdocent = false
                destination1.isDocent = false
            }
        }
    }
    
    
    
    
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
