//
//  ViewCalendario.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import EventKit

class ViewCalendario: UIViewController {
    var alert: UIAlertController!
    
    @IBOutlet var datapicked: UIDatePicker!
    
    @IBOutlet var titleNote: UITextField!
    @IBOutlet var testoNota: UITextField!
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
        titleNote.text = "titolo"
        testoNota.text = "testo"
        
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func allarme(_ title:String, _ message:String){
        alert = UIAlertController(title: "Calendar", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let actionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default)
        alert.addAction(actionOk)
        self.present(self.alert, animated: true, completion: nil)
    }
    
    @IBAction func Invia(_ sender: Any) {
        let eventStore : EKEventStore = EKEventStore()
        
        eventStore.requestAccess(to: .event) { (granted, error) in
            
            if (granted) &&  (error  == nil)
            {
                print("granted \(granted)")
                print("error \(error)")
                
                let event: EKEvent = EKEvent(eventStore: eventStore)
                event.title = self.titleNote.text
                
                event.startDate = Date()
                event.endDate = self.datapicked.date
                event.notes = self.testoNota.text
                event.calendar = eventStore.defaultCalendarForNewEvents
                do {
                    try eventStore.save(event, span: .thisEvent)
                } catch let error as NSError {
                    print("error: \(error)")
                }
                self.allarme("Calendar", "inserito!")
                print("Save Event")
            }
            else {
                print("error : \(error)")
            }
            
            
        }
    }
    }
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */


