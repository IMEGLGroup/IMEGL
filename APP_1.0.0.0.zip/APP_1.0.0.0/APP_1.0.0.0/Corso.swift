//
//  Corso.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 12/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class Corso: NSObject {

}
