//
//  MainCourse.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 14/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import Foundation
class MainCourse: UIViewController, UITableViewDelegate, UITableViewDataSource, UISearchResultsUpdating{

    // è un docvente
    var isdocent: Bool = false
    // istanza del docente loggato se esiste
    var docente : Teacher? = nil
    // istanza dello studente loggato se esiste
    var studente : Student? = nil
    
    @IBOutlet var tableView: UITableView!
    
    @IBOutlet var add: UIBarButtonItem!
    
    var corso = [Course(nomeCorso : "JavaCourse" , nomeTeacher: "Giuseppe Del Monaco", orario : "14-15", location : "aula B2", programmaCorso : "intro al linguaggio..", libri : "Java"),Course(nomeCorso : "Sistemi Dinamici" , nomeTeacher: "Ester Zeoli", orario : "15-16", location : "aula B1", programmaCorso : "Storia dei sistemi..", libri : "Sistemi dinamici")]

    //corsi che vengono stampati
    var filteredCourse = [Course]()

    //barra di ricerca
    let searchController = UISearchController(searchResultsController: nil)
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        if searchController.isActive{
                filteredCourse = corso
            }else if isdocent{
                 filteredCourse = (docente?.corsi)!
                    }else {
                        filteredCourse = (studente?.corsiSeguiti)!
                            add.title = ""
                            add.isEnabled = false
           }
        
        searchController.searchResultsUpdater = self
        searchController.dimsBackgroundDuringPresentation = false
        definesPresentationContext = true
        tableView.tableHeaderView = searchController.searchBar
        
    }
    
    
    func updateSearchResults(for searchController: UISearchController) {
        // If we haven't typed anything into the search bar then do not filter the results

        if searchController.searchBar.text! == "" {
            if isdocent{
                filteredCourse = (docente?.corsi)!
            }else {
                filteredCourse = (studente?.corsiSeguiti)!
            }
        } else {
            filteredCourse = corso.filter{ $0.nomeCorso.lowercased().contains(searchController.searchBar.text!.lowercased()) }
        }
        
        self.tableView.reloadData()
    }
    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
            return filteredCourse.count
    }
    
     // restituisce un oggetto cella della riga
    //    da migliorare
    func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
       
        let cellidentifier = "cell"
        let cell = tableView.dequeueReusableCell(withIdentifier: cellidentifier , for: indexPath ) as! Celle
        
        if isdocent{
                    cell.labelCorso.text =  self.filteredCourse[indexPath.row].nomeCorso
        }else{
            cell.labelCorso.text =  self.filteredCourse[indexPath.row].nomeCorso
            }
        
        return cell
            }
    
    func tableView(_ tableView: UITableView, canEditRowAt indexPath: IndexPath) -> Bool {
        // Return false if you do not want the specified item to be editable.
        return true
    }
    
    func numberOfSections(in tableView: UITableView) -> Int {
        // #warning Incomplete implementation, return the number of sections
        return 1
    }
    
    
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        super .prepare(for: segue, sender: sender)
        if segue.identifier == "createSegue"{
                let destination = segue.destination as! CreateCourseViewController
                destination.teacher = docente
        }
        else if segue.identifier == "viewSegue"{
            let destination = segue.destination as! ViewCorso
            if isdocent{
                let selectedCell = sender as? Celle
                    destination.teacher = docente
                    destination.isDocent = true
                let c = selectedCell?.labelCorso.text
                //passo la cella
                destination.c = c!
                destination.corsiG = corso
        }else {
                let selectedCell = sender as? Celle
                destination.studente = studente
                destination.isDocent = false
                let c = selectedCell?.labelCorso.text
                destination.c = c!
                destination.corsiG = corso
        }
            }
    }
    
}
