//
//  Profile.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 16/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class Profile: UIViewController {

    var isDocent : Bool = true
    var docente : Teacher? = nil
    var studente : Student? = nil
    
    
    @IBOutlet var passwordText: UITextField!
    @IBOutlet var emailText: UITextField!
    @IBOutlet var surnameText: UITextField!
    @IBOutlet var nomeText: UITextField!
    
    @IBAction func done(_ sender: Any) {
    }
    
    override func viewDidLoad() {
        super.viewDidLoad()
       print(docente?.corsi.count)
        if isDocent{
            nomeText.text = docente?.name
            surnameText.text = docente?.cognome
            emailText.text = docente?.mail
            passwordText.text = docente?.password
        }else{
            nomeText.text = studente?.name
            surnameText.text = studente?.cognome
            emailText.text = studente?.mail
            passwordText.text = studente?.password
        }
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationT = segue.destination as! TabController
        let destination0 = destinationT.viewControllers![0] as! MainCourse
        let destination1 = destinationT.viewControllers![1] as! AdviseView
        let destination2 = destinationT.viewControllers![3] as! Setting
        
        if isDocent{
            destination0.docente = docente
            destination0.isdocent = true
            destination2.docente = docente
            destination2.isDocent = true
            destination1.isDocent = true
            destination1.docent = docente
        }else {
            destination0.studente = studente
            destination0.isdocent = false
            destination2.studente = studente
            destination2.isDocent = false
            destination1.isDocent = false
        }
        
    }

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
