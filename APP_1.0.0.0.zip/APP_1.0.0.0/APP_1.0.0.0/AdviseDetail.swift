//
//  AdviseDetail.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 18/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit

class AdviseDetail: UIViewController {

    @IBOutlet var dateAd: UITextField!
    @IBOutlet var textAd: UITextView!
    @IBOutlet var titleA: UITextField!
    @IBOutlet var nomeTeach: UITextField!
    
    @IBOutlet var done: UIBarButtonItem!
    
    var teacher : Teacher? = nil
    
    var studente : Student? = nil
    
    var isDocent = true
    
    var avviso : Advise? = nil
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        titleA.text = avviso?.titolo
        textAd.text = avviso?.corpo
        nomeTeach.text = avviso?.nomeTeacher
        dateAd.text = avviso?.ora
        
        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    

    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        
        let destinationT = segue.destination as! TabController
        let destination0 = destinationT.viewControllers![0] as! MainCourse
        let destination1 = destinationT.viewControllers![1] as! AdviseView
        let destination2 = destinationT.viewControllers![3] as! Setting
        
        if isDocent{
            destination0.docente = teacher
            destination0.isdocent = true
            destination1.docent = teacher
            destination1.isDocent = true
            destination2.docente = self.teacher
            destination2.isDocent = true
        } else{
            destination0.studente = studente
            destination0.isdocent = false
            destination1.isDocent = false
            destination1.student = studente
            destination2.studente = self.studente
            destination2.isDocent = false
        }
        
    }
    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
