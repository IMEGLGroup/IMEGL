//
//  Teacher.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 12/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import Foundation

class Teacher: NSObject {
  
    var name : String
    var cognome : String
    var mail: String
    var corso: String
    var password : String
    var corsi : [Course]
    
    
    //costruttore
    init(name : String, cognome: String, mail : String, corso : String, password: String,corsi :[Course]) {
        
        self.name = name
        self.cognome = cognome
        self.mail = mail
        self.password = password
        self.corso = corso
        self.corsi = corsi
    }
      
        

}
