//
//  Login.swift
//  APP_1.0.0.0
//
//  Created by Del Monaco Giuseppe on 12/02/18.
//  Copyright © 2018 IMEGL. All rights reserved.
//

import UIKit
import Foundation

class Login: UIViewController {

   
    @IBOutlet var mailLogin: UITextField!
    @IBOutlet var passwordLogin: UITextField!
    
    
    var alert: UIAlertController!
    //array statici
    var teacher :[Teacher] = ([Teacher(name: "Giuseppe", cognome: "Del Monaco", mail: "giuseppe.ios@icloud.com", corso: "JavaCourse", password: "password", corsi : [Course(nomeCorso : "JavaCourse" , nomeTeacher: "Giuseppe Del Monaco", orario : "14-15", location : "aula B2", programmaCorso : "intro al linguaggio..", libri : "Java")]),
                               Teacher(name: "Ester", cognome: "Zeoli", mail: "ester.zeoli@icloud.com", corso: "Sistemi Dinamici", password: "password", corsi: [Course(nomeCorso : "Sistemi Dinamici" , nomeTeacher: "Ester Zeoli", orario : "15-16", location : "aula B1", programmaCorso : "Storia dei sistemi..", libri : "Sistemi dinamici")])])
    
    
    var student : [Student] = [Student(nome : "Marco", cognome: "Vella",mail: "marcovella@icloud.com", matricola : "863000391", password: "password",corsiSeguiti: [Course(nomeCorso : "JavaCourse" , nomeTeacher: "Giuseppe Del Monaco", orario : "14-15", location : "aula B2", programmaCorso : "intro al linguaggio..", libri : "Java"),Course(nomeCorso : "Sistemi Dinamici" , nomeTeacher: "Ester Zeoli", orario : "15-16", location : "aula B1", programmaCorso : "Storia dei sistemi..", libri : "Sistemi dinamici")]),
                               Student(nome : "Lorena", cognome: "Ranauro",mail: "lorenaranauro@icloud.com", matricola : "863000391", password: "password", corsiSeguiti: [Course(nomeCorso : "JavaCourse" , nomeTeacher: "Giuseppe Del Monaco", orario : "14-15", location : "aula B2", programmaCorso : "intro al linguaggio..", libri : "Java"),Course(nomeCorso : "Sistemi Dinamici" , nomeTeacher: "Ester Zeoli", orario : "15-16", location : "aula B1", programmaCorso : "Storia dei sistemi..", libri : "Sistemi dinamici")])]
        
    @IBAction func Login(_ sender: Any) {
    }
    
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        let destinationTab = segue.destination as! TabController
        let destination = destinationTab.viewControllers![0] as! MainCourse
        
        if self.mailLogin.text == ""{ //qua si puo controllare che l'email è corretta
            self.mailLogin.placeholder = "Insert mail"
            allarme("Error","Insert your mail")
        }else if self.passwordLogin.text == ""{
            self.passwordLogin.placeholder = "Insert password"
            allarme("Error","Insert your password")
        }else {
            //cerca negli studenti
            var trovato : Bool = false
            if(trovato == false){
            for i in 0 ..< student.count {
                if (mailLogin.text == student[i].mail) && (passwordLogin.text == student[i].password){
                    destination.isdocent = false
                    destination.studente = self.student[i]
                    trovato = true
                    }
                }
                
            }
            //cerca nei professori
            if (trovato == false){
                for j in 0 ..< teacher.count{
                    if (mailLogin.text == teacher[j].mail) && (passwordLogin.text == teacher[j].password){
                   //login
                        destination.isdocent = true
                        destination.docente = self.teacher[j]
                        trovato = true
                        
                  }
                }
            }
            if(trovato == false){
                allarme("Error","User not found")
                
            }
        }
    }
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        // Do any additional setup after loading the view.
    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    func allarme(_ title:String, _ message:String){
        alert = UIAlertController(title: "Login Error", message: message, preferredStyle: UIAlertControllerStyle.alert)
        let actionOk = UIAlertAction(title: "Ok", style: UIAlertActionStyle.default)
        alert.addAction(actionOk)
        self.present(self.alert, animated: true, completion: nil)
    }
    
   
    

    /*
    // MARK: - Navigation

    // In a storyboard-based application, you will often want to do a little preparation before navigation
    override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
        // Get the new view controller using segue.destinationViewController.
        // Pass the selected object to the new view controller.
    }
    */

}
