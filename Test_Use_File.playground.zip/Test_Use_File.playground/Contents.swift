//: Playground - noun: a place where people can play

import Cocoa
import Foundation


let nomefile = "file" //this is the file. we will write to and read from it
let text = "1" //just a text
let text2 = "2"




func writeToDocumentsFile(fileName:String,value:String) {
    let dir = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first
    let path = dir?.appendingPathComponent(nomefile)
    
    let file: FileHandle? = try! FileHandle.init(forWritingTo: path!)
    
    print(file)
    if file != nil {
        // Set the data we want to write
        let data = value.data(using: .utf8)
        print(data)
        // Write it to the file
        file?.seekToEndOfFile()
        file?.write(data!)
        
        // Close the file
        file?.closeFile()
    }
    else {
        print("Ooops! Something went wrong!")
    }
}
writeToDocumentsFile(fileName: nomefile, value: text)

writeToDocumentsFile(fileName: nomefile, value: text2)
//    var filePath = ""
//
//    // Fine documents directory on device
//    let dirs : [String] = NSSearchPathForDirectoriesInDomains(FileManager.SearchPathDirectory.desktopDirectory, FileManager.SearchPathDomainMask.allDomainsMask, true)
//
//    if dirs.count > 0 {
//        let dir = dirs[0] //documents directory
//        filePath = dir.appending("/" + fileName)
//        print("Local path = \(filePath)")
//    } else {
//        print("Could not find local directory to store file")
//        return
//    }
//
//    // Set the contents
//  //  let fileContentToWrite = "Text to be recorded into file"
//
//    do {
//        // Write contents to file
//        try value.write(toFile: filePath, atomically: false, encoding: String.Encoding.utf8)
//    }
//    catch let error as NSError {
//        print("An error took place: \(error)")
//    }
//
//
//    // Read file content. Example in Swift
//    do {
//        // Read file content
//        let contentFromFile = try NSString(contentsOfFile: filePath, encoding: String.Encoding.utf8.rawValue)
//        print(contentFromFile)
//    }
//    catch let error as NSError {
//        print("An error took place: \(error)")
//    }
//}
//writeToDocumentsFile(fileName:nomefile,value:text)
//writeToDocumentsFile(fileName:nomefile,value:text2)
//    //print(fileurl)
////    if FileManager.default.fileExists(atPath: fileurl!.path){
////        do{
////            let fileHandle = try FileHandle.init(forWritingTo: fileurl!)//FileHandle.init(forWritingTo: fileurl!)
////            fileHandle.seekToEndOfFile()
////            fileHandle.write(data)
////            fileHandle.closeFile()
////
////        }catch{print("nope")}
////    }
//
////
////    if let dir = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).last {
////       let fileURL = dir.appendingPathComponent(nomefile)
////        do{
////        try value.write(to: fileURL, atomically: true, encoding: .utf8)
////            print(value)
////        } catch{ print("nope")}
////
////
////    }
//        //    //writing
////           do {
////              try text.write(to: fileURL, atomically: false, encoding: .utf8)
////        //    }
//        //    catch {/* error handling here */}
//        //
//        //    //reading
//        //    do {
//        //        let text2 = try String(contentsOf: fileURL, encoding: .utf8)
//        //    }
//        //    catch {/* error handling here */}
//        //}
//
//
////   // let fileManager = FileManager.default
////    let dir = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first
////
////
//////        let documentsPath = NSSearchPathForDirectoriesInDomains(.desktopDirectory, .userDomainMask, true).first as! NSString
//////
////        // url
////    let path = dir?.appendingPathComponent(nomefile)
////
////
////    print(path)
////
////    let fileHandle: FileHandle? = FileHandle(forReadingAtPath: path)
////
////    print(fileHandle)
////
////
////
////
////    if documentsPath == nil {
////        print("File open failed")
////    } else {
////
////        fileHandle?.seekToEndOfFile()
////        let data = (value as
////            NSString).data(using: String.Encoding.utf8.rawValue)
////        fileHandle?.write(data!)
////        fileHandle?.closeFile()
////
////        }
//
//
//    //dove sta
////    let documentsPath = NSSearchPathForDirectoriesInDomains(.desktopDirectory, .userDomainMask, true).first as! NSString
////
////    // url
////    let path = documentsPath.appendingPathComponent(nomefile)
////
////    print(path)
////
////    do {
////        try value.write(toFile: path, atomically: false, encoding: .utf8)
////
////        print(value)
////
////    }
////        catch{ print("error")}
////}
////
//////    do {
//////        try value.write(to: path, atomically: true, encoding: String.Encoding.utf8)
//////
//////
//////    } catch let error as NSError {
//////
//////        print("ERROR : writing to file \(path) : \(error.localizedDescription)")
//////    }
////
//////   let dir = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask) as NSArray
//////
//////            print(dir)
//////
////            //writing
//////            do {
//////                try value.write(to: fileURL!, atomically: false, encoding: .utf8)
//////
//////
//////            }
////            catch {/* error handling here */}
//
////            //reading
////            do {
////                let text2 = try String(contentsOf: fileURL, encoding: .utf8)
////            }
////            catch {/* error handling here */}
//
//
//
//
//
////func readFromDocumentsFile(fileName:String) -> String {
////
////    let documentsPath = NSSearchPathForDirectoriesInDomains(.documentDirectory, .userDomainMask, true)[0] as NSString
////    let path = documentsPath.appendingPathComponent(fileName)
////
////    var readText : String = ""
////
////    do {
////        try readText = NSString(contentsOfFile: path, encoding: String.Encoding.utf8.rawValue) as String
////    }
////    catch let error as NSError {
////        print("ERROR : reading from file \(fileName) : \(error.localizedDescription)")
////    }
////    return readText
////}



//if let dir = FileManager.default.urls(for: .desktopDirectory, in: .userDomainMask).first {
////    let fileURL = dir.appendingPathComponent(file)
//
//    //writing
//    do {
//        try text.write(to: fileURL, atomically: false, encoding: .utf8)
//    }
//    catch {/* error handling here */}
//
//    //reading
//    do {
//        let text2 = try String(contentsOf: fileURL, encoding: .utf8)
//    }
//    catch {/* error handling here */}
//}
